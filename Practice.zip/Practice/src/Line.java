public class Line {

}
